// Portfolio Application JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initial recommendations data
    const initialRecommendations = [
        {
            name: "Dr. Priya Sharma",
            designation: "Professor, Computer Science Department",
            institution: "Vidyavardhini's College of Engineering and Technology",
            recommendation: "Umera is an exceptional student with a strong passion for cybersecurity and artificial intelligence. Her dedication to learning and practical implementation of security concepts is remarkable. She consistently demonstrates analytical thinking and problem-solving skills that are essential for a successful career in cybersecurity."
        },
        {
            name: "Prof. Rajesh Kumar",
            designation: "Head of Data Science Department",
            institution: "University of Mumbai",
            recommendation: "I have observed Umera's outstanding performance in data science coursework. Her ability to combine theoretical knowledge with practical applications, especially in AI and machine learning projects, is impressive. She shows great potential for research and development in emerging technologies."
        },
        {
            name: "Mr. Arjun Patel",
            designation: "Senior Security Analyst",
            institution: "CyberTech Solutions, Mumbai",
            recommendation: "During Umera's internship preparation sessions, I was impressed by her technical aptitude and enthusiasm for cybersecurity. Her understanding of network security concepts and ethical hacking principles demonstrates her commitment to becoming a skilled cybersecurity professional. I highly recommend her for opportunities in the field."
        }
    ];

    // Store recommendations in memory (since we can't use localStorage)
    let recommendations = [...initialRecommendations];

    // DOM Elements
    const recommendationsList = document.getElementById('recommendationsList');
    const recommendationForm = document.getElementById('recommendationForm');
    const recommendationPopup = document.getElementById('recommendationPopup');
    const closePopupBtn = document.querySelector('.close-popup');
    const homeIcon = document.querySelector('.home-icon');
    const navLinks = document.querySelectorAll('.nav-link');

    // Initialize the application
    init();

    function init() {
        displayRecommendations();
        setupEventListeners();
        setupSmoothScrolling();
    }

    // Display recommendations
    function displayRecommendations() {
        recommendationsList.innerHTML = '';
        
        recommendations.forEach((rec, index) => {
            const recommendationCard = createRecommendationCard(rec, index);
            recommendationsList.appendChild(recommendationCard);
        });
    }

    // Create recommendation card element
    function createRecommendationCard(recommendation, index) {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        card.innerHTML = `
            <div class="recommendation-header">
                <h4 class="recommendation-name">${escapeHtml(recommendation.name)}</h4>
                <p class="recommendation-designation">${escapeHtml(recommendation.designation)}</p>
                <p class="recommendation-institution">${escapeHtml(recommendation.institution)}</p>
            </div>
            <p class="recommendation-text">${escapeHtml(recommendation.recommendation)}</p>
        `;
        
        return card;
    }

    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Setup event listeners
    function setupEventListeners() {
        // Form submission
        recommendationForm.addEventListener('submit', handleFormSubmission);
        
        // Popup close
        closePopupBtn.addEventListener('click', closePopup);
        
        // Home icon click
        homeIcon.addEventListener('click', function(e) {
            e.preventDefault();
            scrollToTop();
        });

        // Close popup when clicking outside
        recommendationPopup.addEventListener('click', function(e) {
            if (e.target === recommendationPopup) {
                closePopup();
            }
        });

        // Keyboard navigation for popup
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && recommendationPopup.style.display === 'block') {
                closePopup();
            }
        });
    }

    // Handle form submission
    function handleFormSubmission(e) {
        e.preventDefault();
        
        // Get form data using direct element access
        const nameInput = document.getElementById('name');
        const designationInput = document.getElementById('designation');
        const institutionInput = document.getElementById('institution');
        const recommendationInput = document.getElementById('recommendation');
        
        const newRecommendation = {
            name: nameInput.value.trim(),
            designation: designationInput.value.trim(),
            institution: institutionInput.value.trim(),
            recommendation: recommendationInput.value.trim()
        };

        // Validate form data
        if (!validateRecommendation(newRecommendation)) {
            return;
        }

        // Add new recommendation to the list
        recommendations.push(newRecommendation);
        
        // Update display
        displayRecommendations();
        
        // Reset form
        recommendationForm.reset();
        
        // Show success popup - ensure this happens
        console.log('Showing popup...');
        showPopup();
        
        // Scroll to recommendations section to show the new recommendation
        setTimeout(() => {
            const newCard = recommendationsList.lastElementChild;
            if (newCard) {
                newCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                newCard.style.background = 'var(--color-secondary)';
                setTimeout(() => {
                    newCard.style.background = '';
                }, 2000);
            }
        }, 500);
    }

    // Validate recommendation data
    function validateRecommendation(rec) {
        const fields = ['name', 'designation', 'institution', 'recommendation'];
        
        for (let field of fields) {
            if (!rec[field] || rec[field].length < 2) {
                alert(`Please enter a valid ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}.`);
                return false;
            }
        }
        
        if (rec.recommendation.length < 20) {
            alert('Please enter a more detailed recommendation (at least 20 characters).');
            return false;
        }
        
        return true;
    }

    // Show popup - improved version
    function showPopup() {
        console.log('showPopup called');
        
        // Make sure popup exists
        if (!recommendationPopup) {
            console.error('Popup element not found');
            return;
        }
        
        // Force display and styling
        recommendationPopup.style.display = 'flex';
        recommendationPopup.style.alignItems = 'center';
        recommendationPopup.style.justifyContent = 'center';
        recommendationPopup.style.position = 'fixed';
        recommendationPopup.style.top = '0';
        recommendationPopup.style.left = '0';
        recommendationPopup.style.width = '100%';
        recommendationPopup.style.height = '100%';
        recommendationPopup.style.zIndex = '2000';
        
        document.body.style.overflow = 'hidden';
        
        console.log('Popup should be visible now');
        
        // Focus on close button for accessibility
        setTimeout(() => {
            if (closePopupBtn) {
                closePopupBtn.focus();
            }
        }, 100);
        
        // Auto-close after 4 seconds
        setTimeout(() => {
            closePopup();
        }, 4000);
    }

    // Close popup
    function closePopup() {
        console.log('closePopup called');
        if (recommendationPopup) {
            recommendationPopup.style.display = 'none';
        }
        document.body.style.overflow = 'auto';
    }

    // Scroll to top
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }

    // Setup smooth scrolling for navigation links
    function setupSmoothScrolling() {
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    const headerHeight = document.querySelector('.header').offsetHeight;
                    const targetPosition = targetSection.offsetTop - headerHeight - 20;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                    
                    // Update active navigation
                    updateActiveNavigation(targetId);
                }
            });
        });
    }

    // Update active navigation link
    function updateActiveNavigation(activeId) {
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === activeId) {
                link.classList.add('active');
            }
        });
    }

    // Intersection Observer for navigation highlighting
    const observerOptions = {
        threshold: 0.3,
        rootMargin: '-100px 0px -50% 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const activeId = '#' + entry.target.id;
                updateActiveNavigation(activeId);
            }
        });
    }, observerOptions);

    // Observe all sections
    document.querySelectorAll('section[id]').forEach(section => {
        observer.observe(section);
    });

    // Add scroll effects
    let lastScrollY = window.scrollY;
    const header = document.querySelector('.header');

    window.addEventListener('scroll', () => {
        const currentScrollY = window.scrollY;
        
        // Header hide/show on scroll
        if (currentScrollY > lastScrollY && currentScrollY > 100) {
            header.style.transform = 'translateY(-100%)';
        } else {
            header.style.transform = 'translateY(0)';
        }
        
        lastScrollY = currentScrollY;
    });

    // Add loading animation to skill cards
    function animateSkillCards() {
        const skillCards = document.querySelectorAll('.skill-card');
        
        const cardObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, index * 100);
                }
            });
        }, { threshold: 0.1 });

        skillCards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            cardObserver.observe(card);
        });
    }

    // Add loading animation to project cards
    function animateProjectCards() {
        const projectCards = document.querySelectorAll('.project-card');
        
        const projectObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, index * 200);
                }
            });
        }, { threshold: 0.1 });

        projectCards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            projectObserver.observe(card);
        });
    }

    // Initialize animations
    setTimeout(() => {
        animateSkillCards();
        animateProjectCards();
    }, 500);

    // Add form validation feedback
    const formInputs = document.querySelectorAll('.form-control');
    formInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateField(this);
            }
        });
    });

    function validateField(field) {
        const value = field.value.trim();
        const isValid = field.type === 'textarea' ? value.length >= 20 : value.length >= 2;
        
        if (!isValid) {
            field.classList.add('error');
            field.style.borderColor = 'var(--color-error)';
        } else {
            field.classList.remove('error');
            field.style.borderColor = 'var(--color-border)';
        }
    }

    // Add typing effect for the main title
    function addTypingEffect() {
        const aboutTitle = document.querySelector('.about-text .name');
        if (aboutTitle) {
            const text = aboutTitle.textContent;
            aboutTitle.textContent = '';
            
            let i = 0;
            const typeWriter = () => {
                if (i < text.length) {
                    aboutTitle.textContent += text.charAt(i);
                    i++;
                    setTimeout(typeWriter, 150);
                }
            };
            
            setTimeout(typeWriter, 1000);
        }
    }

    // Initialize typing effect
    setTimeout(addTypingEffect, 500);

    // Performance optimization: Debounce scroll events
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Apply debounce to scroll handler
    window.addEventListener('scroll', debounce(() => {
        // Additional scroll handling if needed
    }, 10));

    console.log('Portfolio application initialized successfully!');
});